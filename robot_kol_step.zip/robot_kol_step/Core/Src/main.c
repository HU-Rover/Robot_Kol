/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM5_Init(void);
/* USER CODE BEGIN PFP */
uint16_t AS5600_ReadAngle(I2C_HandleTypeDef *hi2c, uint8_t reg);
HAL_StatusTypeDef AS5600_Init(I2C_HandleTypeDef *hi2c);
HAL_StatusTypeDef AS5600_Update_DMA(I2C_HandleTypeDef *hi2c);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define RAD_TO_DEG (180.0 / M_PI)
#define ams5600_Address (0x36 << 1)
#define addr_raw_angle 0x0C
#define CONF_REG 0x07
#define MAX_PWM 500
#define MIN_PWM -500

volatile float filtrelenmis_derece;
volatile float filtrelenmemis_derece;
volatile uint16_t filtrelenmis_aci;
volatile uint16_t ham_aci;
uint16_t ham_hesap,filtreli_hesap;
volatile uint8_t magnet_status; // Mıknatıs durumunu burada tutacağız
HAL_StatusTypeDef last_status;

uint8_t as5600_rx_buf[5];        // Status(1) + RawAngle(2) + Angle(2) = 5 byte
volatile uint8_t dma_ready = 0;


uint16_t eski_aci = 0;
uint32_t durma_sayaci = 0;

typedef struct {
    float target_angle;
    uint8_t direction;
    TIM_HandleTypeDef *timer;
    uint32_t channel;
	uint32_t GPIO_PIN;
	uint32_t pulse_count;
	uint32_t target_pulses;
	uint32_t reducer;
}Robot_Arm;

typedef struct {
    int target_angle;      // Hedef açı (motorun ulaşması gereken açı)
    int current_angle;
    int previous_error;    // Bir önceki hata değeri (PID hesaplaması için)
    int integral;          // Integral bileşeni (PID hesaplaması için)
    int output;            // PID çıktısı (motor kontrolü için PWM değeri)
	int last_time ;
    float Kp;                   // Proportional (P) kazanç
    float Ki;              	    // Integral (I) kazanç
    float Kd; 				    // Derivative (D) kazanç
} Base;

Base base = {0,0,0,0,0,0, 0.03f, 0.00001f, 0.001f};

Robot_Arm shoulder = {0.0,  0 , &htim2, TIM_CHANNEL_1, GPIO_PIN_9, 0, 0, 20};
Robot_Arm elbow = {0.0, 0,&htim3, TIM_CHANNEL_1,GPIO_PIN_7, 0,0, 50};


uint8_t user_buf[100];
uint8_t uart_buf[100];


uint64_t last_message_time = 0;
char tx_buffer[64] = {0};
uint8_t message_received = 0, first_encoder_read =0;
int now = 0;

void move_angle_pwm(Robot_Arm *joint, float time);
void move_gripper(int gripper_pitch, int gripper_roll, int servo);
void Motor_Kontrol_Joint (Base *joint);

int gripper_pitch,gripper_roll, servo;

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size){

	 memcpy(user_buf, uart_buf , Size);
	 char *ptr = (char*)user_buf;
	 shoulder.target_angle = strtof(ptr,&ptr);
	 shoulder.direction = (uint8_t)strtol(ptr, &ptr, 10);
	 elbow.target_angle = strtof(ptr,&ptr);
	 elbow.direction = (uint8_t)strtof(ptr,&ptr);
	 gripper_pitch = (int)strtol(ptr,&ptr,10);
	 gripper_roll = (int)strtol(ptr,&ptr,10);
	 servo = (int)strtol(ptr,&ptr,10);
	 base.target_angle = (int)strtol(ptr,&ptr,10);

	 move_angle_pwm(&shoulder, 0.1);  //Shoulder

	 move_angle_pwm(&elbow, 0.1);   //elbow

	 move_gripper(gripper_pitch, gripper_roll, servo);

	 Motor_Kontrol_Joint(&base);

	 message_received = 1;

	 last_message_time = HAL_GetTick();

	 __HAL_UART_ENABLE_IT(&huart2,UART_IT_RXNE);
}


#define STEPS_PER_REV   12800        // match your DIP switch
#define TIM2_PSC        71          // set in CubeMX, gives 1MHz timer clock
#define TIMER_CLOCK     1000000     // SystemCoreClock / (PSC+1)

volatile uint32_t pulse_count    = 0;
volatile uint32_t target_pulses  = 0;

void move_gripper(int gripper_pitch, int gripper_roll, int servo){

	int left = gripper_pitch + gripper_roll;
	int right = gripper_pitch - gripper_roll;


		if(left > 0){
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, 1);
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, abs(left));
		}

		else if(left < 0){
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, 0);
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, abs(left));
		}

		else{
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, 0);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, 0);
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0);
		}

		if(right > 0){
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 1);
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, abs(right));
		}
		else if(right < 0){
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, 1);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 0);
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, abs(right));
		}
		else{
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, 0);
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, 0);
		__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 0);
		}

	    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, servo);
}

void move_angle_pwm(Robot_Arm *joint, float time){
    uint32_t pulses = (uint32_t)((joint->target_angle / 360.0f) * STEPS_PER_REV*joint->reducer);
    if (pulses == 0) return;

    uint32_t speed_hz = (uint32_t)(pulses / time);

    if (speed_hz < 10)     speed_hz = 10;      // minimum safe speed
    if (speed_hz > 400000) speed_hz = 400000;

    HAL_GPIO_WritePin(GPIOA, joint->GPIO_PIN, joint->direction ? GPIO_PIN_RESET : GPIO_PIN_SET);
    HAL_Delay(1);

    // Set frequency and duty cycle
    joint->timer->Instance->ARR  = (TIMER_CLOCK / speed_hz) - 1;
    joint->timer->Instance->CCR1 = joint->timer->Instance->ARR / 2;
    joint->timer->Instance->CNT  = 0;  // reset counter

    joint->pulse_count   = 0;
    joint->target_pulses = pulses;

    HAL_TIM_PWM_Start_IT(joint->timer, joint->channel);
    __HAL_TIM_ENABLE_IT(joint->timer, TIM_IT_UPDATE);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim->Instance == TIM2) {
    	shoulder.pulse_count = shoulder.pulse_count + 1;
        if (shoulder.pulse_count >= shoulder.target_pulses) {
            HAL_TIM_PWM_Stop_IT(&htim2, TIM_CHANNEL_1);
            __HAL_TIM_DISABLE_IT(&htim2, TIM_IT_UPDATE);

        }
    }

    if (htim->Instance == TIM3) {
            elbow.pulse_count = elbow.pulse_count + 1;
            if (elbow.pulse_count >= elbow.target_pulses) {
                HAL_TIM_PWM_Stop_IT(&htim3, TIM_CHANNEL_1);
                __HAL_TIM_DISABLE_IT(&htim3, TIM_IT_UPDATE);

            }
        }
}

//-------------------------------------- BASE ----------------------------------------------

float error = 0;

int calculatePID(Base *joint, int dt)
{


    if(joint->target_angle - joint->current_angle > 180) error = (joint->target_angle - joint->current_angle - 360)*1000;
    else if(joint->target_angle - joint->current_angle < -180) error = (joint->target_angle - joint->current_angle + 360)*1000;
    else error = (joint->target_angle - joint->current_angle)*1000;

    joint->integral += error * (float)(dt);
    float derivative = (error - joint->previous_error)/(float)dt;
    joint->previous_error = error;

    if(joint->integral * joint->Ki >= 250) joint-> integral = (float)250/joint->Ki;
    if(joint->integral * joint->Ki <= -250) joint-> integral = -(float)250/joint->Ki;

    joint->output = joint->Kp * error + joint->Ki * joint->integral + joint->Kd * derivative;

    if (joint->output > MAX_PWM) joint->output = MAX_PWM;
    if (joint->output < MIN_PWM) joint->output = MIN_PWM;

    return joint->output;
}

void setPWM(int pwmvalue)
{

	if (pwmvalue > 0) {
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, 0);
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, fabs(pwmvalue));
	}
	else if (pwmvalue < 0) {
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 0);
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, fabs(pwmvalue));
	}
	else {
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_2, 0);
		__HAL_TIM_SET_COMPARE(&htim5, TIM_CHANNEL_1, 0);
	}
 }


//-----------------------------------------ENCODER----------------------------------------------
uint8_t read_register(uint8_t Sensor_register)
	{
	    HAL_StatusTypeDef status;
	    uint8_t return_value = 0;

	    status = HAL_I2C_Mem_Read(&hi2c1,ams5600_Address ,Sensor_register, I2C_MEMADD_SIZE_8BIT, &return_value, 1, 100);
	    HAL_Delay(2);
	    /* Check the communication status*/
	    if(status != HAL_OK)
	    {
	        printf("I2C read status error =%#x \n\r",status);
	                /*
	    HAL_ERROR    = 0x01U,
	    HAL_BUSY     = 0x02U,
	    HAL_TIMEOUT  = 0x03U
	             */
	    }

	    return return_value;
	};


	uint16_t readTwo_register(uint8_t Sensor_register)
	{
	      int highByte = read_register(Sensor_register );
	      int lowByte  = read_register(Sensor_register+1);
	      return ( highByte << 8 ) | lowByte;
	};


	void write_register(uint8_t Sensor_register, uint8_t register_value)
	{
	    HAL_StatusTypeDef status = HAL_OK;

	    status = HAL_I2C_Mem_Write(&hi2c1,ams5600_Address , Sensor_register, I2C_MEMADD_SIZE_8BIT, &register_value,1, 100);
	    HAL_Delay(2);
	    /* Check the communication status */
	    if(status != HAL_OK)
	    {
	        printf("I2C write status error =%#x \n\r",status);// Error handling, for example re-initialization of the I2C peripheral
	    }
	}


	uint16_t getRawAngle()
	{
	    return readTwo_register(addr_raw_angle);
	}

	float convertRawAngleToDegrees(uint16_t newAngle)
	{
	  /* Raw data reports 0 - 4095 segments, which is 0.087 of a degree*/
	  float retVal = newAngle * 0.087;
	  return retVal;
	};



	void Encoder_Data(Base *joint){
			joint->current_angle= convertRawAngleToDegrees(getRawAngle());

			if(!first_encoder_read){
				joint->target_angle = joint->current_angle;
				first_encoder_read = 1;
			}
		}


	void Motor_Kontrol_Joint (Base *joint)
			{
						Encoder_Data(&base);
						now = HAL_GetTick();
						int dt = now - joint->last_time;
				        int16_t pwmvalue = calculatePID(joint,dt);
				        joint->last_time = HAL_GetTick();
				        setPWM(pwmvalue);
			}




/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_I2C1_Init();
  MX_TIM5_Init();
  /* USER CODE BEGIN 2 */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_12, 1);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, 1);
  __HAL_UART_ENABLE_IT(&huart2, UART_IT_RXNE);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  while(HAL_GetTick() - last_message_time > 250){
		  shoulder.target_angle = 0;
		  move_angle_pwm(&shoulder, 1);
		  elbow.target_angle = 0;
		  move_angle_pwm(&elbow, 1);
	     }


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 83;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 83;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  HAL_TIM_Base_Start_IT(&htim3);
  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 83;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 3999;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief TIM5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM5_Init(void)
{

  /* USER CODE BEGIN TIM5_Init 0 */

  /* USER CODE END TIM5_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM5_Init 1 */

  /* USER CODE END TIM5_Init 1 */
  htim5.Instance = TIM5;
  htim5.Init.Prescaler = 20;
  htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim5.Init.Period = 999;
  htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim5) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM5_Init 2 */
  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim5, TIM_CHANNEL_2);
  /* USER CODE END TIM5_Init 2 */
  HAL_TIM_MspPostInit(&htim5);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|GPIO_PIN_7|GPIO_PIN_9|GPIO_PIN_11
                          |GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, DC_MOTOR_1_Pin|DC_MOTOR_2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2|DC_MOTOR_2B10_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin PA7 PA9 PA11
                           PA12 */
  GPIO_InitStruct.Pin = LD2_Pin|GPIO_PIN_7|GPIO_PIN_9|GPIO_PIN_11
                          |GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : DC_MOTOR_1_Pin DC_MOTOR_2_Pin */
  GPIO_InitStruct.Pin = DC_MOTOR_1_Pin|DC_MOTOR_2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PB2 DC_MOTOR_2B10_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_2|DC_MOTOR_2B10_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
